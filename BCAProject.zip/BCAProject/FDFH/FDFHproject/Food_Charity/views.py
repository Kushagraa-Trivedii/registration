from django.shortcuts import render

# Create your views here.
def index(request):

	return render (request,'Food_Charity/index.html')

def about(request):

	return render (request,'Food_Charity/about.html')

def login(request):

	return render (request,'Food_Charity/login.html')

def reg(request):

	return render (request,'Food_Charity/reg.html')

def post(request):
	
	return render (request,'Food_Charity/post.html')

def more(request):
	
	return render (request,'Food_Charity/more.html')

def explore(request):
	
	return render (request,'Food_Charity/explore.html')

def cont(request):
	
	return render (request,'Food_Charity/cont.html')

def gall(request):
	
	return render (request,'Food_Charity/gall.html')