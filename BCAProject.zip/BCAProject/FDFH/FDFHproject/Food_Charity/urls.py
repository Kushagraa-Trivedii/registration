from django.urls import path
#from  django.conf.urls import url
from . import views
urlpatterns =[path('',views.index,name='index'),
				path('about/',views.about),
				path('login/',views.login),
				path('reg/',views.reg),
				path('post/',views.post),
				path('more/',views.more),
				path('explore/',views.explore),
				path('cont/',views.cont),
				path('gall/',views.gall),
			 ]